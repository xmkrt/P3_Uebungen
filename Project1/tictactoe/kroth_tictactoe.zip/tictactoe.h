void tictactoe();
void draw();
void play();
int win();
int feld(int f);
