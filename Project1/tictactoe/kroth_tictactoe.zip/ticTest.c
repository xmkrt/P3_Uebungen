#include <stdio.h>
#include "tictactoe.h"

 int main(int argc, char *argv[]) {
	tictactoe();
	getchar();
	getchar();
}